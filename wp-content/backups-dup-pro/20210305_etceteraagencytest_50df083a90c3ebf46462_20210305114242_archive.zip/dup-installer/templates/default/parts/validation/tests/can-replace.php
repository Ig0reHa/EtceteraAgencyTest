<?php
/**
 *
 * @package templates/default
 *
 */
defined('ABSPATH') || defined('DUPXABSPATH') || exit;
?><p>
    The home path of the source site was '/'.
    Having '/' as the home path of the package makes it impossible to run a search-and-replace on the database.
    You can still restore the package on the same server as the source site or install it on the current server and manually replace paths in the database.
</p>